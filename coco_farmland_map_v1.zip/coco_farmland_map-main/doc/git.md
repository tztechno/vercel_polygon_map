```
cd farmland
https://github.com/tztechno/coco_farmland_map.git


package.jsonを修正
npm install
npm run dev

https://github.com/tztechno/coco_farmland_map.git
cd farmland
git pull


cd polygon
git init
git remote add origin https://github.com/tztechno/coco_farmland_map.git
git push -u origin main

git add .
git commit -m “2024-08-03”
git push -u origin main

git push -f origin main

cd farmland
npm run build

cd farmland
npm run dev

http://localhost:3000

http://localhost:3001

npm install


```